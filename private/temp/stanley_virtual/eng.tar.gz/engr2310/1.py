def function():
    number = 5
    print(number)

number = 10
function()
print(number)
