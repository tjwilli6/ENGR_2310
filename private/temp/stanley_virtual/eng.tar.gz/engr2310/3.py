def proc(x):
    x = 2 * x * x

def main():
    num = 10
    proc(num)
    print(num)

main()
