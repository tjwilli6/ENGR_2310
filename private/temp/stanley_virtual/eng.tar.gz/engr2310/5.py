def addnumbers(num1, num2):
    print("Sum is: ", num1 + num2)

addnumbers(5,7)
