a = float(input("Enter the first number: "))
b = float(input("Enter the second number: "))
ratio = a/b
if b==0:
    print("Cannot divid by zero!")
else:
    print("a,divided by,b,is",ratio)
