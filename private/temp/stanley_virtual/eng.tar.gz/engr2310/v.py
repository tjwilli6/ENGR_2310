r=5
v=(4/3 * 3.14 * r**3)
print(v)
