x=7500
y=1300
z=-1000
r=( x**2 + y**2 + z**2 )**(1/2)
unit_vectorx= x/r
unit_vectory= y/r
unit_vectorz= z/r
print(unit_vectorx)
print(unit_vectory)
print(unit_vectorz)
