number1 = input("enter number 1")
number2 = input("enter the second number")
total = number1 + number2
print(total)
