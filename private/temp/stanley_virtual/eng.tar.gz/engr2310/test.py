a = 0
while a < 90:
    a = a + .1
    print(a)
