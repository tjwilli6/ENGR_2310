# Cameron Stanley
# 2/5/2021
# In this code i starts out as -1 but as long as i is not 11.
# The code will count i up by three every time till it hits 11.
# It will print every number i + 3 is till it is 11. 
i = -1
while i < 11:
    i+= 3
    print(i)
