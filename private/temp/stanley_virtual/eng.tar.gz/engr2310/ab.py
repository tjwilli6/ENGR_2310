x = float(input("Enter a number!"))
a1 = 50
b1 = 100
a2 = -50
b2 = -100
if a1 < x and x < b1:
    print("True")
elif a2 > x and x > b2:
    print("True")
else:
    print("False")
