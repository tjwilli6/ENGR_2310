def proc():
    name = "Toby"

name = "Taylor"
proc()
print(name)
